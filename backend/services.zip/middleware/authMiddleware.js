const jwt = require("jsonwebtoken");

const authMiddleware = (req, res, next) => {
  try {
    console.log('incomming req');
    
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        message: "دسترسی غیرمجاز است",
      });
    }

    const token = authHeader.split(" ")[1];

    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET
    );

    req.user = decoded;

    next();
  } catch (error) {
    return res.status(401).json({
      message: "توکن نامعتبر یا منقضی شده است",
    });
  }
};

module.exports = authMiddleware;